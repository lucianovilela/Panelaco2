window.onload = function() {

    var w = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    var h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    var imgDir = "hdpi";
    if(w <= 768){
        imgDir = "ldpi";
    }else if(w <= 992){
        imgDir = "mdpi";   
    }
    

    Crafty.init(w, h-50, 'game');
//    Crafty.canvas();
//    
    var status = 'FIM';
    function iniciar() {
        status = 'INICIAL';
        return false;
    }


    var posicaoFinal;
    var variacao;
    var v = 0;
    var x =0;
    var dif = 0;
    
    
    Crafty.e("2D, Canvas, Image")
        .attr({
        x: w / 2 - 100,
        y: (h-60) / 2,
        w: 200,
        h: 20
    })
        .image("img/"+imgDir+"/lapis2.png");
    
    var player = Crafty.e("2D, Canvas, Image")
        .attr({
        x: w / 2 - 10,
        y: (h-50) / 2 - 100,
        w: 20,
        h: 200
    })
        .origin("center")
        .image("img/"+imgDir+"/lapis.png");


    
    

    player.bind('EnterFrame', function () {

        switch (status) {
            case 'INICIAL':
                posicaoFinal = respostaPergunta();
                variacao = Crafty.math.randomInt(5, 10);
                //variacao = 10;
                

                v = Crafty.math.randomInt(1,5);
                status = 'MOV';
//                console.log("posicaoFinal:" + posicaoFinal);
//                console.log("rotation:"+this.rotation);
                break;
            case 'MOV':
//                console.log("dif:" + dif);
                if(Crafty.math.abs(posicaoFinal - this.rotation)>4){
                    this.rotation = posicaoFinal> this.rotation ?this.rotation+4:this.rotation-4;
                    dif = dif -4;
                }
                else{
                    status = 'EXEC';
                }
                break;

            case 'EXEC':
//                console.log("variacao:" + variacao);
//                console.log("v:" + v);
//                console.log("rotation:"+this.rotation);
                if (variacao === 0) {
                    status = 'FINALIZAR';
                } else {
                    this.rotation = this.rotation + v;
                    x = x+1;
                    if (x === variacao   ) {
                        
                        v = v*-1;
                        
                        variacao = variacao -1;
                        x=0;
                    }
                    
                }
                break;
            case 'FINALIZAR':
                $("#q1").css("background-color", "white");
                $("#q2").css("background-color", "white");
                $("#q3").css("background-color", "white");
                $("#q4").css("background-color", "white");

                var q = parseInt(this.rotation/90)+1;
                if(q==1){q=2;}
                else if(q==2){q=4;}
                else if(q==4){q=1;}
                console.log("q:" + q);
                $("#q"+q).css("background-color", "red");
                status='FIM';
                break;
            case 'FIM':
                break;

        }



    });


    function respostaPergunta(){
        
       return  Crafty.math.randomInt(0, 360);
    }

    $("#btn").click(function () {

        console.log("status inicial");
        status = 'INICIAL';
    });


}